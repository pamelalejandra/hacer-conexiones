function editProfile(elemento){
    let cardName = document.querySelector(".cardName");
    cardName.innerText = "Martha Gomez";
}

function removeUser(element,){
    let user = element.closest(".card-list-item");
    user.remove();
}
